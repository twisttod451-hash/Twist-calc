# Twist Calc Android Project

This project is organized with the folder structure needed for GitHub Actions to build the Android APK.

## Important
Keep the folders and file paths exactly as they are. In particular, keep `.github/workflows/build-apk.yml` in that exact location so GitHub Actions can find the build workflow.

## Uploading from a phone
GitHub's mobile web upload screen may not unpack a ZIP automatically. If you upload this ZIP as a single file, GitHub will store it as a ZIP and will not build the app from its contents. You need to upload the extracted project contents while preserving the folder structure, or use a Git client/app that can push a repository.

After the project files are in the repository, open the **Actions** tab and check the Android APK build workflow.
